import { useState, useEffect } from "react";
import { Upload, Loader2, AlertCircle, CheckCircle2 } from "lucide-react";

interface DiseaseData {
  name: string;
  confidence: number;
  treatment: string;
  symptoms: string;
}

const DISEASE_DATABASE: Record<string, DiseaseData> = {
  "powdery_mildew": {
    name: "Powdery Mildew",
    confidence: 92,
    treatment: "Apply sulfur dust or neem oil every 7 days. Ensure good air circulation. Remove affected leaves. Avoid overhead watering.",
    symptoms: "White powdery coating on leaves, stems, and flowers"
  },
  "early_blight": {
    name: "Early Blight",
    confidence: 88,
    treatment: "Remove infected leaves immediately. Apply copper fungicide every 10 days. Mulch soil to prevent spore splash.",
    symptoms: "Brown spots with concentric rings on lower leaves, yellow halos"
  },
  "late_blight": {
    name: "Late Blight",
    confidence: 85,
    treatment: "Remove infected plant parts. Use fungicides containing chlorothalonil or mancozeb. Improve air circulation.",
    symptoms: "Water-soaked spots on leaves, white fungal growth on undersides, rapid spread"
  },
  "leaf_spot": {
    name: "Leaf Spot",
    confidence: 90,
    treatment: "Remove affected leaves. Apply fungicide weekly. Avoid overhead irrigation. Disinfect tools between plants.",
    symptoms: "Circular brown or black spots with yellow halos on leaves"
  },
  "rust": {
    name: "Rust",
    confidence: 87,
    treatment: "Apply sulfur or neem-based fungicide. Remove infected leaves. Improve air circulation around plants.",
    symptoms: "Yellow-orange or reddish pustules on leaf undersides, yellowing of upper surface"
  },
  "healthy": {
    name: "Healthy Plant",
    confidence: 95,
    treatment: "Continue regular watering, fertilizing, and pruning. Monitor for any signs of disease.",
    symptoms: "No visible signs of disease or stress"
  }
};

export function DiseaseDetection() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<{
    disease: string;
    confidence: number;
    treatment: string;
    symptoms: string;
  } | null>(null);
  const [referenceImages, setReferenceImages] = useState<string[]>([]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    // Load reference images from Kaggle dataset if available
    const loadReferenceImages = async () => {
      try {
        const response = await fetch('/kaggle_datasets/');
        if (response.ok) {
          setReferenceImages(['/kaggle_datasets/']);
        }
      } catch (err) {
        console.log('Kaggle dataset not yet downloaded. Using mock data.');
      }
    };
    loadReferenceImages();
  }, []);

  const analyzePlant = () => {
    if (!selectedImage) return;

    setAnalyzing(true);
    // Simulate AI analysis with disease database
    setTimeout(() => {
      const diseases = Object.entries(DISEASE_DATABASE);
      const randomDiseaseEntry = diseases[Math.floor(Math.random() * diseases.length)];
      const disease = randomDiseaseEntry[1];
      
      setResult({
        disease: disease.name,
        confidence: disease.confidence,
        treatment: disease.treatment,
        symptoms: disease.symptoms,
      });
      setAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-muted to-background py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Plant Disease Detection
          </h1>
          <p className="text-lg text-foreground/70">
            Upload an image of your plant to detect diseases and get treatment recommendations
          </p>
        </div>

        {/* Upload Section */}
        <div className="bg-card rounded-2xl shadow-lg border border-border p-8 mb-8">
          <div
            className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
              selectedImage
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary hover:bg-muted"
            }`}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            {selectedImage ? (
              <div className="space-y-4">
                <img
                  src={selectedImage}
                  alt="Uploaded plant"
                  className="max-h-80 mx-auto rounded-lg shadow-md"
                />
                <label className="inline-flex items-center gap-2 bg-secondary text-secondary-foreground px-4 py-2 rounded-lg cursor-pointer hover:bg-secondary/90 transition-colors">
                  <Upload className="w-4 h-4" />
                  Change Image
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  <Upload className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Upload Plant Image</h3>
                  <p className="text-sm text-foreground/70 mb-4">
                    Drag and drop your image here, or click to browse
                  </p>
                  <label className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-lg cursor-pointer hover:bg-primary/90 transition-colors shadow-md">
                    <Upload className="w-5 h-5" />
                    Select Image
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            )}
          </div>

          {selectedImage && (
            <div className="mt-6 text-center">
              <button
                onClick={analyzePlant}
                disabled={analyzing}
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-3 rounded-lg hover:bg-primary/90 transition-colors shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {analyzing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Analyzing Plant...
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-5 h-5" />
                    Analyze Plant
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Result Section */}
        {result && (
          <div className="bg-card rounded-2xl shadow-lg border border-border overflow-hidden">
            <div className="bg-primary/10 px-6 py-4 border-b border-border">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-primary" />
                <h2 className="text-xl font-semibold">Analysis Complete</h2>
              </div>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2 text-foreground/70">
                    Detected Disease
                  </h3>
                  <p className="text-2xl font-bold text-primary">
                    {result.disease}
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2 text-foreground/70">
                    Confidence Score
                  </h3>
                  <div className="flex items-baseline gap-2">
                    <p className="text-2xl font-bold text-primary">
                      {result.confidence}%
                    </p>
                    <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-primary h-full rounded-full transition-all"
                        style={{ width: `${result.confidence}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3">Symptoms</h3>
                <div className="bg-muted/50 rounded-lg p-4 mb-4">
                  <p className="text-foreground/80 leading-relaxed">
                    {result.symptoms}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-primary" />
                  Treatment Recommendations
                </h3>
                <div className="bg-muted/50 rounded-lg p-4">
                  <p className="text-foreground/80 leading-relaxed">
                    {result.treatment}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
