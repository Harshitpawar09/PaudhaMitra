import { Link } from "react-router";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Scan, BookOpen, Droplets, ArrowRight } from "lucide-react";

export function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-muted to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
                Your Smart Gardening Companion
              </h1>
              <p className="text-lg text-foreground/70 mb-8 leading-relaxed">
                Detect plant diseases, learn how to grow plants, and get smart watering suggestions based on weather.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/disease-detection"
                  className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors shadow-md hover:shadow-lg"
                >
                  <Scan className="w-5 h-5" />
                  Detect Plant Disease
                </Link>
                <Link
                  to="/plant-guide"
                  className="inline-flex items-center justify-center gap-2 bg-secondary text-secondary-foreground px-6 py-3 rounded-lg hover:bg-secondary/90 transition-colors shadow-md hover:shadow-lg"
                >
                  <BookOpen className="w-5 h-5" />
                  Explore Plant Guide
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1552670070-7901ae9ffce2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwZ3JlZW4lMjBwbGFudHMlMjBnYXJkZW5pbmd8ZW58MXx8fHwxNzcyNzkwNTc3fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Healthy plants in garden"
                  className="w-full h-auto"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-primary text-primary-foreground px-6 py-4 rounded-xl shadow-xl hidden md:block">
                <p className="font-semibold">Grow with confidence</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Powerful Features for Plant Care
            </h2>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Everything you need to keep your plants healthy and thriving
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1: Disease Detection */}
            <div className="bg-card rounded-2xl shadow-lg overflow-hidden border border-border hover:shadow-xl transition-shadow">
              <div className="h-48 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1728297753604-d2e129bdb226?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbGFudCUyMGRpc2Vhc2UlMjBsZWFmJTIwZGV0ZWN0aW9ufGVufDF8fHx8MTc3MjcxODgxNXww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Plant disease detection"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Scan className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Image Upload Disease Detection</h3>
                <p className="text-foreground/70 mb-4">
                  Upload an image of your plant leaf and detect possible diseases using AI.
                </p>
                <Link
                  to="/disease-detection"
                  className="inline-flex items-center gap-2 text-primary hover:gap-3 transition-all"
                >
                  Try it now
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            {/* Feature 2: Plant Guide */}
            <div className="bg-card rounded-2xl shadow-lg overflow-hidden border border-border hover:shadow-xl transition-shadow">
              <div className="h-48 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1641230894485-1299385f425a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbGFudCUyMGdyb3d0aCUyMGd1aWRlJTIwc2VlZGxpbmd8ZW58MXx8fHwxNzcyNzkwNTc4fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Plant growth guide"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Plant Growth Guide</h3>
                <p className="text-foreground/70 mb-4">
                  Enter a plant name and get a complete guide including planting, watering, sunlight, and soil requirements.
                </p>
                <Link
                  to="/plant-guide"
                  className="inline-flex items-center gap-2 text-primary hover:gap-3 transition-all"
                >
                  Learn more
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            {/* Feature 3: Watering Suggestion */}
            <div className="bg-card rounded-2xl shadow-lg overflow-hidden border border-border hover:shadow-xl transition-shadow">
              <div className="h-48 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1626014186581-449dfb459e15?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlcmluZyUyMHBsYW50cyUyMHdhdGVyJTIwZHJvcGxldHN8ZW58MXx8fHwxNzcyNzkwNTc4fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Watering plants"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Droplets className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Weather-Based Watering Suggestion</h3>
                <p className="text-foreground/70 mb-4">
                  Enter plant details and check whether your plant needs watering based on weather conditions.
                </p>
                <Link
                  to="/watering-suggestion"
                  className="inline-flex items-center gap-2 text-primary hover:gap-3 transition-all"
                >
                  Get suggestions
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
