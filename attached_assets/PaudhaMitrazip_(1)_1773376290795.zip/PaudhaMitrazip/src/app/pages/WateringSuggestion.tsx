import { useState, useEffect } from "react";
import { Droplets, Cloud, ThermometerSun, Calendar, AlertCircle } from "lucide-react";
import Papa from "papaparse";

interface WateringResult {
  temperature: number;
  weatherCondition: string;
  recommendation: string;
  shouldWater: boolean;
}

export function WateringSuggestion() {
  const [plantName, setPlantName] = useState("");
  const [lastWatered, setLastWatered] = useState("");
  const [location, setLocation] = useState("");
  const [result, setResult] = useState<WateringResult | null>(null);
  const [csvData, setCsvData] = useState<any[]>([]);

  useEffect(() => {
    fetch("/attached_assets/dataset/Indoor_Plant_Health_and_Growth_Factors.csv")
      .then(response => {
        if (!response.ok) throw new Error("Failed to fetch CSV");
        return response.text();
      })
      .then(csvString => {
        const results = Papa.parse(csvString, { header: true, skipEmptyLines: true });
        setCsvData(results.data);
      })
      .catch(err => console.error("Error loading CSV:", err));
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!plantName || !lastWatered || !location) {
      return;
    }

    const query = plantName.toLowerCase().trim();
    const csvMatch = csvData.find(row => 
      row.Plant_ID && row.Plant_ID.toLowerCase().includes(query)
    );

    if (csvMatch) {
      const freq = parseInt(csvMatch.Watering_Frequency_days) || 3;
      const amount = csvMatch.Watering_Amount_ml;
      const soilMoisture = parseFloat(csvMatch["Soil_Moisture_%"]) || 50;
      
      const shouldWater = soilMoisture < 40;
      
      setResult({
        temperature: parseFloat(csvMatch.Room_Temperature_C) || 22,
        weatherCondition: csvMatch.Sunlight_Exposure || "Indoor",
        shouldWater,
        recommendation: shouldWater 
          ? `Based on your plant's data, it needs ${amount}ml of water. Current soil moisture is low (${soilMoisture}%).`
          : `Your plant's soil moisture is healthy (${soilMoisture}%). Next scheduled watering is in ${freq} days.`,
      });
    } else {
      // Mock fallback
      const mockWeatherData: WateringResult[] = [
        {
          temperature: 28,
          weatherCondition: "Sunny",
          recommendation: "Water your plant today. The weather is hot and sunny, which increases water evaporation.",
          shouldWater: true,
        },
        {
          temperature: 22,
          weatherCondition: "Cloudy",
          recommendation: "You can skip watering today. The cloudy weather reduces water loss. Water your plant tomorrow if soil feels dry.",
          shouldWater: false,
        },
        {
          temperature: 18,
          weatherCondition: "Rainy",
          recommendation: "Rain expected tomorrow. Water your plant after 2 days. The rainfall will provide sufficient moisture.",
          shouldWater: false,
        },
      ];
      const randomResult = mockWeatherData[Math.floor(Math.random() * mockWeatherData.length)];
      setResult(randomResult);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-muted to-background py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Smart Watering Suggestion
          </h1>
          <p className="text-lg text-foreground/70">
            Get personalized watering recommendations based on weather conditions
          </p>
        </div>

        {/* Input Form */}
        <div className="bg-card rounded-2xl shadow-lg border border-border p-8 mb-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block mb-2 text-foreground/70">
                <span className="flex items-center gap-2">
                  <Droplets className="w-4 h-4" />
                  Plant Name
                </span>
              </label>
              <input
                type="text"
                value={plantName}
                onChange={(e) => setPlantName(e.target.value)}
                placeholder="e.g., Tomato, Rose, Basil"
                className="w-full px-4 py-3 rounded-lg bg-input-background border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                required
              />
            </div>

            <div>
              <label className="block mb-2 text-foreground/70">
                <span className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Last Watered Time
                </span>
              </label>
              <input
                type="date"
                value={lastWatered}
                onChange={(e) => setLastWatered(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-input-background border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                required
              />
            </div>

            <div>
              <label className="block mb-2 text-foreground/70">
                <span className="flex items-center gap-2">
                  <Cloud className="w-4 h-4" />
                  City or Location
                </span>
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g., Mumbai, Delhi, Bangalore"
                className="w-full px-4 py-3 rounded-lg bg-input-background border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors shadow-md hover:shadow-lg"
            >
              Check Watering Suggestion
            </button>
          </form>
        </div>

        {/* Output Card */}
        {result && (
          <div className="bg-card rounded-2xl shadow-lg border border-border overflow-hidden">
            <div
              className={`px-6 py-4 border-b border-border ${
                result.shouldWater
                  ? "bg-primary/10"
                  : "bg-secondary/20"
              }`}
            >
              <div className="flex items-center gap-2">
                <Droplets
                  className={`w-6 h-6 ${
                    result.shouldWater ? "text-primary" : "text-secondary-foreground"
                  }`}
                />
                <h2 className="text-xl font-semibold">
                  {result.shouldWater ? "Watering Recommended" : "Hold Off on Watering"}
                </h2>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Temperature */}
                <div className="bg-muted/50 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <ThermometerSun className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-foreground/70">Current Temperature</p>
                      <p className="text-2xl font-bold text-primary">
                        {result.temperature}°C
                      </p>
                    </div>
                  </div>
                </div>

                {/* Weather Condition */}
                <div className="bg-muted/50 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <Cloud className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-foreground/70">Weather Condition</p>
                      <p className="text-2xl font-bold text-primary">
                        {result.weatherCondition}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recommendation */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-primary" />
                  Watering Recommendation for {plantName}
                </h3>
                <div className={`rounded-lg p-4 ${
                  result.shouldWater
                    ? "bg-primary/10 border border-primary/20"
                    : "bg-secondary/20 border border-secondary"
                }`}>
                  <p className="text-foreground/80 leading-relaxed text-lg">
                    {result.recommendation}
                  </p>
                </div>
              </div>

              {/* Additional Tips */}
              <div className="bg-muted/30 rounded-lg p-4 border border-border">
                <h4 className="font-semibold mb-2 text-sm text-foreground/70">
                  General Watering Tips
                </h4>
                <ul className="space-y-1 text-sm text-foreground/70">
                  <li>• Check soil moisture before watering - stick your finger 1-2 inches deep</li>
                  <li>• Water early morning or late evening to minimize evaporation</li>
                  <li>• Water at the base of the plant, not the leaves</li>
                  <li>• Ensure proper drainage to prevent root rot</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
