import { useState, useEffect } from "react";
import { Search, Sun, Droplets, Sprout, FlaskConical, Leaf } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import Papa from "papaparse";

interface PlantData {
  name: string;
  scientificName: string;
  image: string;
  planting: string;
  watering: string;
  sunlight: string;
  soil: string;
  fertilizer: string;
}

export function PlantGuide() {
  const [searchQuery, setSearchQuery] = useState("");
  const [plantData, setPlantData] = useState<PlantData | null>(null);
  const [csvData, setCsvData] = useState<any[]>([]);

  useEffect(() => {
    fetch("/attached_assets/dataset/Indoor_Plant_Health_and_Growth_Factors.csv")
      .then(response => {
        if (!response.ok) throw new Error("Failed to fetch CSV");
        return response.text();
      })
      .then(csvString => {
        const results = Papa.parse(csvString, { header: true, skipEmptyLines: true });
        setCsvData(results.data);
      })
      .catch(err => console.error("Error loading CSV:", err));
  }, []);

  const plantDatabase: Record<string, PlantData> = {
    tomato: {
      name: "Tomato",
      scientificName: "Solanum lycopersicum",
      image: "https://images.unsplash.com/photo-1732915169246-272552804bbb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b21hdG8lMjBwbGFudCUyMGdhcmRlbnxlbnwxfHx8fDE3NzI3MjE5NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
      planting: "Plant tomato seeds indoors 6-8 weeks before the last frost. Transplant seedlings outdoors when they're 6-10 inches tall and all danger of frost has passed. Space plants 24-36 inches apart in rows 3-4 feet apart.",
      watering: "Water deeply 2-3 times per week, providing 1-2 inches of water weekly. Water at the base of the plant to avoid wetting foliage. Increase watering during fruit development.",
      sunlight: "Full sun (6-8 hours of direct sunlight daily). Tomatoes need plenty of sunlight to produce sweet, flavorful fruit.",
      soil: "Well-draining, nutrient-rich soil with pH 6.0-6.8. Add compost or aged manure before planting. Mulch around plants to retain moisture.",
      fertilizer: "Apply balanced fertilizer (10-10-10) at planting. Switch to low-nitrogen, high-phosphorus fertilizer when flowering begins. Feed every 2-3 weeks during growing season.",
    },
    rose: {
      name: "Rose",
      scientificName: "Rosa spp.",
      image: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=1080",
      planting: "Plant bare-root roses in early spring or container roses anytime during growing season. Dig a hole twice as wide as the root ball. Plant with graft union 2 inches above soil in cold climates.",
      watering: "Water deeply once or twice a week, providing 1 inch of water. Water early morning at the base. Avoid overhead watering to prevent disease.",
      sunlight: "Full sun (at least 6 hours daily). Morning sun is ideal as it helps dry dew from leaves.",
      soil: "Rich, well-draining soil with pH 6.0-6.5. Add organic matter like compost. Good drainage is essential to prevent root rot.",
      fertilizer: "Feed with rose-specific fertilizer in early spring when new growth appears. Apply every 4-6 weeks during growing season. Stop feeding 6 weeks before first frost.",
    },
    basil: {
      name: "Basil",
      scientificName: "Ocimum basilicum",
      image: "https://images.unsplash.com/photo-1618375569909-3c8616cf7733?w=1080",
      planting: "Sow seeds indoors 6 weeks before last frost or direct sow after frost danger passes. Plant 10-12 inches apart. Pinch off flower buds to encourage leaf production.",
      watering: "Keep soil consistently moist but not waterlogged. Water deeply when top inch of soil is dry, typically daily in hot weather. Avoid wetting leaves.",
      sunlight: "Full sun (6-8 hours daily). Can tolerate partial shade in hot climates. Provide afternoon shade if temperatures exceed 90°F regularly.",
      soil: "Well-draining, rich soil with pH 6.0-7.0. Add compost for nutrients. Ensure good drainage to prevent root diseases.",
      fertilizer: "Light feeding with balanced liquid fertilizer (5-5-5) every 2-3 weeks. Avoid over-fertilizing which reduces flavor. Use organic compost tea for best results.",
    },
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.toLowerCase().trim();
    
    // Check static database first
    const staticPlant = plantDatabase[query];
    if (staticPlant) {
      setPlantData(staticPlant);
      return;
    }

    // Then check CSV data
    const csvMatch = csvData.find(row => 
      row.Plant_ID && row.Plant_ID.toLowerCase().includes(query)
    );

    if (csvMatch) {
      setPlantData({
        name: csvMatch.Plant_ID,
        scientificName: "Indoor Variety",
        image: "https://images.unsplash.com/photo-1545241047-6083a3684587?w=1080",
        planting: `This plant reaches a height of ${csvMatch.Height_cm}cm and has ${csvMatch.Leaf_Count} leaves. Health Notes: ${csvMatch.Health_Notes}.`,
        watering: `Requires ${csvMatch.Watering_Amount_ml}ml of water every ${csvMatch.Watering_Frequency_days} days. Current soil moisture: ${csvMatch["Soil_Moisture_%"]}%.`,
        sunlight: csvMatch.Sunlight_Exposure || "Indoor lighting",
        soil: `${csvMatch.Soil_Type} soil`,
        fertilizer: `Recommended: ${csvMatch.Fertilizer_Type} (${csvMatch.Fertilizer_Amount_ml}ml)`,
      });
    } else {
      setPlantData(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-muted to-background py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Plant Growth Guide
          </h1>
          <p className="text-lg text-foreground/70">
            Search for a plant to get comprehensive care instructions
          </p>
        </div>

        {/* Search Section */}
        <div className="bg-card rounded-2xl shadow-lg border border-border p-8 mb-8">
          <form onSubmit={handleSearch} className="space-y-4">
            <div>
              <label className="block mb-2 text-foreground/70">
                Enter Plant Name
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="e.g., Tomato, Rose, Basil"
                  className="w-full px-4 py-3 pr-12 rounded-lg bg-input-background border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-foreground/40" />
              </div>
            </div>
            <button
              type="submit"
              className="w-full bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors shadow-md hover:shadow-lg"
            >
              Search Plant
            </button>
          </form>

          {searchQuery && !plantData && (
            <div className="mt-6 p-4 bg-muted/50 rounded-lg text-center">
              <p className="text-foreground/70">
                Plant not found. Try searching for: Tomato, Rose, or Basil
              </p>
            </div>
          )}
        </div>

        {/* Result Card */}
        {plantData && (
          <div className="bg-card rounded-2xl shadow-lg border border-border overflow-hidden">
            <div className="h-64 overflow-hidden">
              <ImageWithFallback
                src={plantData.image}
                alt={plantData.name}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-8">
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-foreground mb-2">
                  {plantData.name}
                </h2>
                <p className="text-lg text-foreground/60 italic">
                  {plantData.scientificName}
                </p>
              </div>

              <div className="space-y-6">
                {/* Planting */}
                <div className="flex gap-4">
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Sprout className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-2">How to Plant</h3>
                    <p className="text-foreground/70 leading-relaxed">
                      {plantData.planting}
                    </p>
                  </div>
                </div>

                {/* Watering */}
                <div className="flex gap-4">
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Droplets className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-2">Watering Frequency</h3>
                    <p className="text-foreground/70 leading-relaxed">
                      {plantData.watering}
                    </p>
                  </div>
                </div>

                {/* Sunlight */}
                <div className="flex gap-4">
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Sun className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-2">Sunlight Requirement</h3>
                    <p className="text-foreground/70 leading-relaxed">
                      {plantData.sunlight}
                    </p>
                  </div>
                </div>

                {/* Soil */}
                <div className="flex gap-4">
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Leaf className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-2">Soil Type</h3>
                    <p className="text-foreground/70 leading-relaxed">
                      {plantData.soil}
                    </p>
                  </div>
                </div>

                {/* Fertilizer */}
                <div className="flex gap-4">
                  <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <FlaskConical className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-2">Fertilizer Recommendation</h3>
                    <p className="text-foreground/70 leading-relaxed">
                      {plantData.fertilizer}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
