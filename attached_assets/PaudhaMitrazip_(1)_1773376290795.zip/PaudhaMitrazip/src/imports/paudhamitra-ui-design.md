

Design a **modern, clean, and responsive website UI** for a plant care platform called **PaudhaMitra**. The platform helps users detect plant diseases from images, get plant growth guides, and receive watering suggestions based on weather.

The design should be suitable for implementation using **HTML, CSS, and React.js**. Components should be modular and easily convertible into **React components**.

The UI should follow a **green, nature-inspired theme** with soft colors like green, light beige, and white. The design should feel friendly, minimal, and easy for beginner gardeners to use.

Ensure the design is **fully responsive for desktop and mobile devices**.

---

# Pages to Design

## 1. Landing Page (Home)

Purpose: Introduce the platform and guide users to features.

Sections:

### Navbar

Include a top navigation bar containing:

* Logo: **PaudhaMitra**
* Navigation links:

  * Home
  * Disease Detection
  * Plant Guide
  * Watering Suggestion
  * About

Navbar should be sticky and responsive.

### Hero Section

Main introduction section including:

* Large headline:
  “Your Smart Gardening Companion”
* Subheading describing the platform:
  “Detect plant diseases, learn how to grow plants, and get smart watering suggestions based on weather.”
* Two buttons:

  * Detect Plant Disease
  * Explore Plant Guide

Include a large illustration or image of plants or gardening.

### Features Section

Three feature cards displayed in a grid layout:

Feature 1
Image Upload Disease Detection
Description: Upload an image of your plant leaf and detect possible diseases using AI.

Feature 2
Plant Growth Guide
Description: Enter a plant name and get a complete guide including planting, watering, sunlight, and soil requirements.

Feature 3
Weather-Based Watering Suggestion
Description: Enter plant details and check whether your plant needs watering based on weather conditions.

Each feature card should have:

* Icon
* Title
* Short description
* Button

### Footer

Include:

* Website name
* Short description
* Social media icons
* Copyright text

---

# 2. Disease Detection Page

Purpose: Allow users to upload an image and analyze plant disease.

Layout should include:

### Page Title

“Plant Disease Detection”

### Upload Section

A centered card containing:

* Drag and drop image upload area
* Upload button
* Preview of uploaded image

### Analyze Button

Large button labeled:

“Analyze Plant”

### Result Section

Below the upload section display results such as:

Disease Name
Confidence Score
Possible Treatment Advice

The result card should have:

* plant image preview
* detected disease
* percentage accuracy
* suggestion text

---

# 3. Plant Growth Guide Page

Purpose: Provide plant care instructions.

### Page Title

“Plant Growth Guide”

### Search Section

Include:

* Input field labeled:
  “Enter Plant Name”

* Search Button

### Result Card

When plant data is found display:

Plant Name
Plant Image

Sections inside the card:

How to Plant
Watering Frequency
Sunlight Requirement
Soil Type
Fertilizer Recommendation

Each section should have icons and organized layout.

---

# 4. Watering Suggestion Page

Purpose: Help users determine when to water plants.

### Page Title

“Smart Watering Suggestion”

### Input Form

Fields:

Plant Name
Last Watered Time
City or Location

Include a submit button labeled:

“Check Watering Suggestion”

### Output Card

Display:

Current Temperature
Weather Condition
Watering Recommendation

Example:

“Rain expected tomorrow. Water your plant after 2 days.”

---

# UI Design Style

Color Palette:
Primary: Green (#2E7D32)
Secondary: Light Green (#A5D6A7)
Background: White / Off-white
Accent: Beige or light earth tone

Typography:
Use modern fonts like **Poppins or Inter**.

Buttons:
Rounded corners
Soft shadows
Green primary buttons

Cards:
Rounded corners
Soft shadows
Minimalist style

---

# Component Structure for React

Ensure UI can be easily divided into React components such as:

Navbar
HeroSection
FeatureCard
UploadCard
PlantGuideCard
WaterSuggestionCard
Footer

Each section should be designed as **reusable components**.

---

# Output Requirement

Generate high-fidelity UI mockups including:

Desktop layout
Mobile responsive layout
Component-based design suitable for **HTML, CSS, and React.js implementation**.

