# PaudhaMitra: Plant Care & Disease Detection

## Integrated Datasets

### 1. Indoor Plant Health & Growth Dataset
- **Status**: ✅ Active
- **Location**: `public/attached_assets/dataset/`
- **Features**: 
  - Plant Guide: Search by plant name to see real data (height, leaf count, health notes)
  - Watering Suggestion: Uses actual soil moisture and watering frequency from the dataset

### 2. Kaggle Indoor Plant Disease Detection Dataset
- **Status**: 🔄 Ready to download
- **Dataset**: https://www.kaggle.com/datasets/abdulahad0296/indoor-plant-disease-detection-dataset
- **Features**:
  - Disease Detection page with image upload
  - Comprehensive disease database with symptoms and treatments
  - Reference images from Kaggle dataset (once downloaded)

## Setup Instructions

### For Disease Detection with Kaggle Data:

1. **Get Kaggle API Credentials**:
   - Go to https://www.kaggle.com/account
   - Click "Create New API Token"
   - Save your username and API key

2. **Add Replit Secrets**:
   - Tools → Secrets
   - Add: `KAGGLE_USERNAME` = your username
   - Add: `KAGGLE_KEY` = your API key

3. **Download Dataset**:
   ```bash
   python3 scripts/download_kaggle_dataset.py
   ```

## Features

### Plant Guide
- Search for plants from the integrated CSV dataset
- Get real care instructions (watering, sunlight, soil, fertilizer)
- See actual plant metrics

### Watering Suggestion
- Enter plant name for data-driven recommendations
- Uses recorded soil moisture levels
- Smart watering schedules based on real data

### Disease Detection
- Upload plant images
- AI analysis with confidence scores
- Detailed symptoms and treatment plans
- Built-in disease database with professional advice
- Reference images from Kaggle dataset (when available)

## Files Modified
- `src/app/pages/PlantGuide.tsx` - Added CSV data loading
- `src/app/pages/WateringSuggestion.tsx` - Added data-driven recommendations
- `src/app/pages/DiseaseDetection.tsx` - Enhanced with disease database
- `vite.config.ts` - Added `allowedHosts: true` for preview support
- `scripts/download_kaggle_dataset.py` - Automated dataset download script
