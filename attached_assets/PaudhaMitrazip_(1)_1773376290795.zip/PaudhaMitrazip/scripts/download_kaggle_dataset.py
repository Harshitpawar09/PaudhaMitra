#!/usr/bin/env python3
import os
import subprocess
import sys
from pathlib import Path

# Ensure Kaggle credentials are set
kaggle_username = os.environ.get('KAGGLE_USERNAME')
kaggle_key = os.environ.get('KAGGLE_KEY')

if not kaggle_username or not kaggle_key:
    print("❌ Error: KAGGLE_USERNAME or KAGGLE_KEY not found in secrets")
    print("Please add them in Tools → Secrets")
    sys.exit(1)

# Create .kaggle directory and credentials
kaggle_dir = Path.home() / '.kaggle'
kaggle_dir.mkdir(exist_ok=True)

kaggle_json = kaggle_dir / 'kaggle.json'
kaggle_json.write_text(f'{{"username":"{kaggle_username}","key":"{kaggle_key}"}}')
kaggle_json.chmod(0o600)

# Create output directory
output_dir = Path('public/kaggle_datasets')
output_dir.mkdir(parents=True, exist_ok=True)

print("📥 Downloading Indoor Plant Disease Detection Dataset...")
try:
    subprocess.run(
        ['kaggle', 'datasets', 'download', '-d', 'abdulahad0296/indoor-plant-disease-detection-dataset', '-p', str(output_dir)],
        check=True
    )
    print("✅ Dataset downloaded successfully!")
    print(f"📁 Location: {output_dir}")
    
    # List downloaded files
    files = list(output_dir.glob('*'))
    print(f"\n📦 Contents ({len(files)} items):")
    for f in files[:10]:
        print(f"  - {f.name}")
    if len(files) > 10:
        print(f"  ... and {len(files) - 10} more items")
        
except subprocess.CalledProcessError as e:
    print(f"❌ Error downloading dataset: {e}")
    sys.exit(1)
except FileNotFoundError:
    print("❌ Error: kaggle CLI not installed")
    print("Installing kaggle package...")
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'kaggle'], check=True)
    print("Please run this script again")
    sys.exit(1)
