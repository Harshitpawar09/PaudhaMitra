# Plant Care Dataset

This directory contains the dataset used for plant health and growth analysis.

## Files
- `Indoor_Plant_Health_and_Growth_Factors.csv`: Main dataset with plant health metrics.
- `Untitled_spreadsheet_1772818751466.xlsx`: Additional spreadsheet data.

## Integration
The data is used in the Plant Guide and Watering Suggestion pages to provide evidence-based care instructions.
