# Plant Health & Growth Dataset

Integrated dataset containing metrics for indoor plants.

## Features
- `Plant_ID`: Name of the plant.
- `Height_cm`: Current height.
- `Leaf_Count`: Total number of leaves.
- `Health_Notes`: Qualitative health observations.
- `Watering_Amount_ml`: Recommended water volume.
- `Watering_Frequency_days`: Days between watering.
- `Sunlight_Exposure`: Light requirements.
- `Soil_Moisture_%`: Current moisture level.
- `Soil_Type`: Recommended soil.

## Website Integration
- **Plant Guide**: Automatically populates care instructions when a matching plant is searched.
- **Watering Suggestion**: Uses real-time soil moisture and frequency data to provide smart recommendations.
