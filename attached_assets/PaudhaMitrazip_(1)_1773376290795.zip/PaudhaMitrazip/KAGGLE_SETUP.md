# Kaggle Dataset Integration Setup

## Step 1: Get Your Kaggle API Credentials

1. Go to https://www.kaggle.com/account
2. Scroll down to "API" section
3. Click "Create New API Token"
4. This downloads a `kaggle.json` file with your username and key

## Step 2: Add to Replit Secrets

1. In your Replit project, go to **Tools** → **Secrets**
2. Create two new secrets:
   - **Name:** `KAGGLE_USERNAME` | **Value:** Your Kaggle username
   - **Name:** `KAGGLE_KEY` | **Value:** Your API key (the long string from kaggle.json)

## Step 3: Download the Dataset

Run this command in the shell:
```bash
python3 scripts/download_kaggle_dataset.py
```

This will:
- Download the Indoor Plant Disease Detection dataset
- Extract it to `public/kaggle_datasets/`
- Make it accessible to the web app

## Step 4: Use the Dataset

The Disease Detection page will load plant disease images from the downloaded dataset and use them for reference analysis.
